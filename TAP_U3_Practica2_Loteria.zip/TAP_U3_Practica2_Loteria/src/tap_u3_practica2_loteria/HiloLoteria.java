
package tap_u3_practica2_loteria;

import java.io.File;
import java.io.FilenameFilter;
import java.lang.System.Logger;
import java.lang.System.Logger.Level;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import javax.swing.ImageIcon;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class HiloLoteria extends Thread {
    VLoteria v;
    ArrayList<Integer> cartasloteria = new ArrayList<>();
    List<Integer> numeros;

    public HiloLoteria(VLoteria v) {
        this.v = v;
        llenado();
        numeros = nCarta(1, 54);
    }

    public void llenado() {
        for (int i = 1; i <= 54; i++) {
            cartasloteria.add(i);
        }
    }

    public static List<Integer> nCarta(int min, int max) {
        List<Integer> num = new ArrayList<>();
        for (int i = min; i <= max; i++) {
            num.add(i);
        }
        Collections.shuffle(num);

        return num;
    }

    public void run() {
        while (!cartasloteria.isEmpty()) {
            int numeroAleatorio = numeros.remove(0);
            v.tirar("src/CartasLoteria/" + numeroAleatorio + ".png");

            try {
                sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
